function [Xout, n_fuel, Nout, Tout,Q_recyc,n_h2,Q_extra] = combust_mf(Tin_air,Xin_air,Nin_air, Tinfuel,Xinfuel,Nin_fuel, TIT,Q_preheat)
erxn1 = 1;
erxn2 = 1;
erxn3 = 1;
h_air = enthalpy(Tin_air+200);
LHVH2 = zeros(length(TIT),1)+240420; %Lower HEating Value of H2
% Reactions occuring in combustor %
hrxn1 = 2*h_air.H2O+h_air.CO-h_air.CH4-1.5*h_air.O2; %Ch4 + 1.5 O2 --> CO + 2 H2O
hrxn2 = h_air.CO2-h_air.CO-.5*h_air.O2; %CO + .5 O2 --> CO2 
hrxn3 = h_air.H2O-h_air.H2-.5*h_air.O2; %H2 + .5 O2 -->  H2O


[T_noFuel,x_noFuel,N_noFuel,Q_recyc] = combust(T7,X7,N7, Tfuel,X6,N6,Q_preheat,TIT);n_fuel = zeros(length(TXNin_air(:,1)),1);
n_h2 = zeros(length(TIT),1);
Xout = x_noFuel;
Tout = T_noFuel;
Nout = N_noFuel;
% x_fuel = zeros(length(TIT),7);
A = find(T_noFuel<TIT);
B = find(T_noFuel>TIT);
h_out = zeros(length(TIT),1);
if ~isempty(A)%min(T_noFuel)<TIT
    Q_hv = 8e5;
    x_fuel.CH4(A,1) = 1;
    T_fuel = zeros(length(TIT),1)+500;
    [~,h_TIT] = enthalpy2(TIT);
    [~,h_noFuel] = enthalpy2(T_noFuel);
    hTIT = (h_TIT.*x_noFuel)./N_noFuel;
    hnoFuel = (h_noFuel.*x_noFuel).*N_noFuel;
    n_fuel(A) = (sum(hTIT(A))-sum(h_noFuel(A)))/(Q_hv);
    error = 100;
    while max(abs(error))>.1
        R1 =(x_fuel.CH4(A).*n_fuel(A))*erxn1;
        R2 =((x_fuel.CO(A).*n_fuel(A)+R1))*erxn2;
        R3 =(x_fuel.H2(A).*n_fuel(A))*erxn3;

        Nout(A) = N_noFuel(A) + n_fuel + .5*R1 - .5*R2 - .5*R3;

        Xout.CH4(A) = ((x_noFuel.CH4(A).*N_noFuel(A) + x_fuel.CH4(A).*n_fuel(A)) - R1)./Nout(A);
        Xout.CO(A) = ((x_noFuel.CO(A).*N_noFuel(A)) + R1-R2)./Nout(A);
        Xout.CO2(A) = ((x_noFuel.CO2(A).*N_noFuel(A)) + R2)./Nout(A);
        Xout.H2(A) = ((x_noFuel.H2(A).*N_noFuel(A)) - R3)./Nout(A);
        Xout.H2O(A) = ((x_noFuel.H2O(A).*N_noFuel(A)) + R3 + 2*R1)./Nout(A);
        Xout.N2(A) = ((x_noFuel.N2(A).*N_noFuel(A)))./Nout(A);
        Xout.O2(A) = ((x_noFuel.O2(A).*N_noFuel(A)) - 1.5*R1 - .5*R2 - .5*R3)./Nout(A);
        [~,h_fuel] = enthalpy2(T_fuel);
        hfuel = (h_fuel.CH4.*x_fuel.CH4)./n_fuel;
        h_out(A) = hnoFuel(A)+hfuel(A)-(R1.*hrxn1(A))-(R2.*hrxn2(A))-(R3.*hrxn3(A));
        
        Tout(A) = TIT(A);
        [~,h_TIT] = enthalpy2(TIT);
        hTIT = (h_TIT.*Xout).*Nout;
        error = (hTIT(A) - h_out(A))./(mean(SpecHeat(TIT(A))).*Nout(A));
        
        n_fuel(A) = n_fuel(A) + (hTIT(A) - h_out(A))./Q_hv;
        A = A(find(abs(error)>.1));
    end
end
Q_extra = zeros(length(TIT),1);
if ~isempty(B) %min(T_noFuel)>TIT
    [~,h_TIT] = enthalpy2(TIT);
    hTIT = (h_TIT.*Xout).*Nout;
    [~,h_noFuel] = enthalpy2(T_noFuel, x_noFuel, N_noFuel);
    hnoFuel = h_noFuel.*x_nofuel.*N_noFuel;
    Q_extra(B) = hnoFuel(B)-hTIT(B);
%     Q_preheat(B) = Q_preheat(B) - Q_extra(B);
    Tout(B) = TIT(B);
    n_h2(B) = Q_extra(B)./LHVH2(B);
end
